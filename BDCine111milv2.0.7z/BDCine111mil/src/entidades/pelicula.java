/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import dao.peliculasDao;
import java.util.List;

/**
 *
 * @author alumno
 */
public class pelicula {
    
    private int id;
    private String nombre;
    private String genero;
    private String idioma;
    
    public pelicula(int id,String nombre,String genero, String idioma)
    {
        this.nombre= nombre;
        this.id=id;
        this.genero=genero;
        this.idioma= idioma;
    }
     public int getId() {
        return this.id;
    }

    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

     public String getGenero() {
        return genero;
    }

    public void setGenero(String Genero) {
        this.genero = Genero;
    }

     public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma    ;
    }

    
    public int guardarPelicula()
    {
        peliculasDao  peliDao= new peliculasDao();
        return peliDao.guardarPelicula(this);
        
        
    }
    
    public static List<pelicula> retornarPeliculas()
    {
         peliculasDao  peliDao= new peliculasDao();
        return peliDao.retornarPeliculas();
    }
    
    public  int borrarPeliculas()
    {
         peliculasDao  peliDao= new peliculasDao();
        return peliDao.borarPelicula(this);
    }
    
    
    public String toString()
    {
        return this.id +" "+this.getNombre()+" "+this.getGenero()+" "+this.getIdioma();
    }
    
    
}
